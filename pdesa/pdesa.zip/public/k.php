<?php
$kon = mysqli_connect("localhost","mfahri","tik","sidpr") ;

?>
